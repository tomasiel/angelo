#include<stdio.h>
int main()
{
	printf("thanks for nothing");
	return 0;
}